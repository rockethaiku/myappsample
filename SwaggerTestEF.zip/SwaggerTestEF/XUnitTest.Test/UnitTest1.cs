using Microsoft.EntityFrameworkCore;
using Repository;
using Swagger.Entities;
using SwaggerTestEF.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace XUnitTest.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Add_writes_to_database()
        {
            var options = new DbContextOptionsBuilder<PeopleContext>()
                .UseInMemoryDatabase(databaseName: "write_to_database")
                .Options;

            // Run the test against one instance of the context
            using (var context = new PeopleContext(options))
            {
                var service = new HomeController(context);
                
                service.AddPerson(CreateNew(11));
                context.SaveChanges();
            }

            
            using (var context = new PeopleContext(options))
            {

                IQueryable<Person> rtn = from temp in context.People select temp;
                var list = rtn.ToList();
                Assert.Single(list);
                
            }
        }
        private Person CreateNew(int id)
        {
           return new Person
            {
                Id = id,
                Age = 32,
                FirstName = "Luke",
                LastName = "Skywalker",
                Addresses = new List<Address> { new Address { City = "Calgary", Id = 23, State = "AB", StreetAddress = "Kitchner Rd", ZipCode = "007" } },
                EmailAddresses = new List<Email> { new Email { EmailAddress = "first@abc.com", Id = 121 }, new Email { EmailAddress = "second@abc.com", Id = 44 } }
            };
            
        }
        [Fact]
        public void Find_searches_url()
        {
            var options = new DbContextOptionsBuilder<PeopleContext>()
                .UseInMemoryDatabase(databaseName: "Find_Lastname")
                .Options;

            // Insert seed data into the database using one instance of the context
            using (var context = new PeopleContext(options))
            {
                context.People.Add(CreateNew(22));
                context.People.Add(CreateNew(33));
                context.People.Add(CreateNew(44));
                context.SaveChanges();
            }

            // Use a clean instance of the context to run the test
            using (var context = new PeopleContext(options))
            {
                var service = new HomeController(context);
                var result = service.GetByLastName("Skywalker").Value.ToArray();
                Assert.Equal(3, result.Length);
            }
        }
    }
}

