﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Repository;
using Swagger.Entities;

namespace SwaggerTestEF
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //services.AddDbContext<PeopleContext>(options => {
            //    new DbContextOptionsBuilder<PeopleContext>()
            //          .UseInMemoryDatabase(Guid.NewGuid().ToString());

            //});

            //services.AddDbContext<PeopleContext>(opt =>  opt.UseInMemoryDatabase(Guid.NewGuid().ToString()));
            services.AddDbContext<PeopleContext>(opt => opt.UseInMemoryDatabase("localdb"));


            services.AddMvc(options => options.EnableEndpointRouting = false).SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo

                { Version = "v1", Title = "SwaggerTestEF", Description = "Swagger Test EF Web API" });
            });
        }
        private static void AddTestData(PeopleContext context)
        {
            var testUser1 = new Person
            {
                Id = 11,
                Age=32,
                FirstName = "Luke",
                LastName = "Skywalker", Addresses= new List<Address> { new Address { City = "Calgary", Id = 23, State = "AB", StreetAddress = "Kitchner Rd", ZipCode = "007" } } ,
                EmailAddresses=  new List<Email> { new Email { EmailAddress="first@abc.com" , Id=121}, new Email { EmailAddress = "second@abc.com", Id = 44 } }
            };

            context.People.Add(testUser1);

            var testPost1 = new Person
            {
                Id = 55,
                Age = 22,
                FirstName = "Tom",
                LastName = "Sawyer", Addresses = new List<Address> { new Address { City = "Edmonton", Id = 8, State = "AB", StreetAddress = "Asmara Rd", ZipCode = "001" } } ,
                EmailAddresses = new List<Email> { new Email { EmailAddress = "first@klm.com", Id = 11 }, new Email { EmailAddress = "second@klm.com", Id = 4 } }
            };
            context.People.Add(testPost1);

            context.SaveChanges();
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
                
            });
            //using (var context = app.ApplicationServices.GetService<PeopleContext>())
            //{
            //    AddTestData(context);
            //}
            app.UseMvc();
            using (var serviceScope = app.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<PeopleContext>();

                AddTestData(context);
            }
            
        }
    }
}
