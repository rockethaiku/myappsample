﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Repository;
using Swagger.Entities;

namespace SwaggerTestEF.Controllers
{
    [Route("v1")]
    [ApiController]
    public class HomeController : ControllerBase
    {


        private readonly PeopleContext _services;
        public HomeController(PeopleContext services)
        {
            _services = services;
        }
        [HttpPost]
        [Route("AddPerson")]
        public ActionResult<Person> AddPerson(Person person)
        {
            //var p = _services.Add(person);
            var p = _services.People.Add(person).Entity;
            _services.SaveChanges();
            if (p == null) return NotFound();
            return p;
        }
        [HttpGet]
        [Route("GetPeopleByLastName")]
        public ActionResult<List<Person>> GetByLastName(string lastname)
        {
            var people = _services.People;
            var lst = people
                .Include(a => a.Addresses)
                .Include(e => e.EmailAddresses)
                .Where(n => n.LastName.Equals(lastname,StringComparison.OrdinalIgnoreCase))
                //.Where(x => x.Age >= 18 && x.Age <= 65)

                .ToList();
            if (lst.Count == 0)
            {
                return NotFound();

            }
            return lst;
        }
        [HttpGet]
        [Route("GetAll")]
        public async Task<IActionResult> Get()
        {
            var users = await _services.People
                .Include(u => u.EmailAddresses)
                .ToArrayAsync();

            var response = users.Select(u => new
            {
                firstName = u.FirstName,
                lastName = u.LastName,
                email = u.EmailAddresses.Select(p => p.EmailAddress)
            });

            return Ok(response);
        }
    }
}
