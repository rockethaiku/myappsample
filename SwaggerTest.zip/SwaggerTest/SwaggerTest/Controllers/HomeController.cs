﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SwaggerTest.Models;
using SwaggerTest.Services;

namespace SwaggerTest.Controllers
{
    [Route("v1")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly IInventoryServices _services;
        public HomeController(IInventoryServices services)
        {
            _services = services;
        }
        [HttpPost]
        [Route("AddInventoryItems")]
        public ActionResult<InventoryItem> AddInventoryItems(InventoryItem item)
        {
            var inventoryItem = _services.AddInventoryItem(item);
            if (inventoryItem == null) return NotFound();
            return inventoryItem;
        }
        [HttpGet]
        [Route("GetInventoryItems")]
        public ActionResult<Dictionary<string, InventoryItem>> GetInventoryItems()
        {
            var inventoryItems = _services.GetInventoryItems();
            if (inventoryItems.Count == 0)
            {
                return NotFound();

            }
            return inventoryItems;
        }
    }
}
