﻿namespace SwaggerTest.Services
{
    public  class InventoryItem
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public double Price { get; set; }
    }
}